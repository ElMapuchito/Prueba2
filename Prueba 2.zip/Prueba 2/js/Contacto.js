$(document).ready(function() {
  $("#formulario").validate({
      rules: {
      nombre : {
          required: true,
          minlength: 10
      },
      empresa: {
          required: true,
          minlength: 10
      },
      email: {
          required: true,
          email: true
      },
      celular: {
          required: false
      },
      requerimiento: {
          required: true,
          minlength: 30
      }
      },
      messages : {
          nombre: {
              required: "Porfavor ingrese un nombre",
              minlength: "El minimo es de 10 caracteres"
          },
          empresa: {
              required: "Porfavor ingrese una empresa",
              minlength: "El minimo es de 10 caracteres"
          },
          email: {
              required: "Es necesario su correo electronico",
              email: "El email tiene que tener el formato: abc@domain.tld"
          },
          requerimiento: {
              required: "Porfavor ingrese su requerimiento",
              minlength: "El minimo es de 30 caracteres"
          }
      }
  });
  });